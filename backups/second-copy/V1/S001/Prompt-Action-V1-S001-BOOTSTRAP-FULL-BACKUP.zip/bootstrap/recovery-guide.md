# Prompt Action S001 Bootstrap Recovery

One-time baseline bootstrap before STEP 10. Restore activation remains STEP 12 scope.
Prompt bytes are accepted only when their SHA-256 exactly matches the protected STEP 00 map derived from the verified V22.5.1 rescue source.
