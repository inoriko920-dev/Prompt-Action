# Prompt Action S001 Baseline Recovery

S001 uses seven exact V22.5.1 prompt payloads plus the hash-exact official Prompt 3 v22.5.2 release, normalized as V1/R1 before any post-baseline release. Restore activation remains STEP 12 scope.
